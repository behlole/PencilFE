export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDZ0GUAMS-jo1JrBBKWwIbDdZl148UDwn8",
    authDomain: "pencil-b3b26.firebaseapp.com",
    projectId: "pencil-b3b26",
    storageBucket: "pencil-b3b26.appspot.com",
    messagingSenderId: "81130529831",
    appId: "1:81130529831:web:4c2a1cd5b286ad5ea91a02",
    measurementId: "G-G50K6R02NH"
  }
};
