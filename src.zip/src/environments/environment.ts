// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDZ0GUAMS-jo1JrBBKWwIbDdZl148UDwn8",
    authDomain: "pencil-b3b26.firebaseapp.com",
    projectId: "pencil-b3b26",
    storageBucket: "pencil-b3b26.appspot.com",
    messagingSenderId: "81130529831",
    appId: "1:81130529831:web:4c2a1cd5b286ad5ea91a02",
    measurementId: "G-G50K6R02NH"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
